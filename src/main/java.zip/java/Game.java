//Bohnanza

public class Game {
	
	public static void main(String[] args) throws InterruptedException {
		GUI gui = new GUI();
	}
	
}
